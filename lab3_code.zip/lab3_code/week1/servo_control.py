import RPi.GPIO as GPIO
import subprocess
import time

GPIO.setmode(GPIO.BCM)
GPIO.setup(26, GPIO.OUT)
dt=1.54
fre=1/((20+dt)*0.001)
dc=dt/(20+dt)*100
p = GPIO.PWM(26,fre)
p.start(dc)
for i in range (150, 130,-2):
    dt=i*0.01
    fre=1/((20+dt)*0.001)
    dc=dt/(20+dt)*100
    p.ChangeFrequency(fre)
    p.ChangeDutyCycle(dc)
    #print i
    #print " Speed increment"
    s1="Clockwise: frequency: " + str(round(fre,2))+"Hz, pause width: "+str(dt)+"ms, duty cycle: "+str(round(dc,2))+'%.'
    print(s1)
    
    time.sleep(3)
for i in range (150, 170, 2):
    dt=i*0.01
    fre=1/((20+dt)*0.001)
    dc=dt/(20+dt)*100
    p.ChangeFrequency(fre)
    p.ChangeDutyCycle(dc)
    #print i
    #print "CounterClockwise: Speed increment "
    s1="CounterClockwise: frequency: " + str(round(fre,2))+"Hz, pause width: "+str(dt)+"ms, duty cycle: "+str(round(dc,2))+'%.'
    print(s1)
    time.sleep(3)

p.stop()
GPIO.cleanup()
