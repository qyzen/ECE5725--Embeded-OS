import pygame
from pygame.locals import* # for event mouse variables
import os
import time
import RPi.GPIO as GPIO
import subprocess


#os.putenv('SDL_VIDEODRIVER','fbcon') #display on piTFT
#os.putenv('SDL_FBDEV','/dev/fb1') 
#os.putenv('SDL_MOUSEDRV','TSLIB') #track mouse clicks on piTFT
#os.putenv('SDL_MOUSEDEV','/dev/input/touchscreen')

pygame.init()
#pygame.mouse.set_visible(False)
WHITE=255,255,255
RED = 255,0,0
GREEN = 0,255,0
BLACK=0,0,0
COLOR=RED
screen=pygame.display.set_mode((320,240))
my_font_buttons=pygame.font.Font(None,25)
my_font_his=pygame.font.Font(None,20)
my_buttons={(240,220):'quit',(160,120):'STOP'}
my_his={'Left History':(50,50),'Right History':(265,50)}
my_left_value={(50,100):'Stop',(50,150):'Stop',(50,200):'Stop'}
my_left_time={(100,100):'0',(100,150):'0',(100,200):'0'}
my_right_value={(255,100):'Stop',(255,150):'Stop',(255,200):'Stop'}
my_right_time={(305,100):'0',(305,150):'0',(305,200):'0'}
screen.fill(BLACK)  #Erase the work space

GPIO.setmode(GPIO.BCM)

#GIPO for Servo
GPIO.setup(26, GPIO.OUT) #for left servo
GPIO.setup(6, GPIO.OUT) #for right servo

# GPIo for buttons
GPIO.setup(17, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(22, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(27, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(23, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(5, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(13, GPIO.IN, pull_up_down=GPIO.PUD_UP)


# Initial setup for left servo
dt_l=1.5
fre_l=1/((20+dt_l)*0.001)
dc_l=dt_l/(20+dt_l)*100
p_l = GPIO.PWM(26,fre_l)
p_l.start(dc_l)

# Initial setup for right servo
dt_r=1.5
fre_r=1/((20+dt_r)*0.001)
dc_r=dt_r/(20+dt_r)*100
p_r = GPIO.PWM(6,fre_r)
p_r.start(dc_r)








# Left servo clockwise
def GPIO27_callback(channel):
    print('Left servo clockwise')
    global dt_l
    global dt_r
    dt_l = 1.3
    fre_l=1/((20+dt_l)*0.001)
    dc_l=dt_l/(20+dt_l)*100
    p_l.ChangeFrequency(fre_l)
    p_l.ChangeDutyCycle(dc_l)
    my_left_value[(50,200)]=my_left_value[(50,150)]
    my_left_value[(50,150)]=my_left_value[(50,100)]
    my_left_value[(50,100)]='Clkwise'
    end = time.time()
    cost = end - start
    my_left_time[(100,200)]=my_left_time[(100,150)]
    my_left_time[(100,150)]=my_left_time[(100,100)]
    my_left_time[(100,100)]=str(int(cost))
    
    
    

# Left servo stop
def GPIO23_callback(channel):
    print('Left servo stop')
    global dt_l
    global dt_r
    dt_l = 0
    fre_l=1/((20+dt_l)*0.001)
    dc_l=dt_l/(20+dt_l)*100
    p_l.ChangeFrequency(fre_l)
    p_l.ChangeDutyCycle(dc_l)
    my_left_value[(50,200)]=my_left_value[(50,150)]
    my_left_value[(50,150)]=my_left_value[(50,100)]
    my_left_value[(50,100)]='Stop'
    end = time.time()
    cost = end - start
    my_left_time[(100,200)]=my_left_time[(100,150)]
    my_left_time[(100,150)]=my_left_time[(100,100)]
    my_left_time[(100,100)]=str(int(cost))


# Left servo counter-clockwise
def GPIO22_callback(channel):
    print('Left servo counter-clockwise')
    global dt_l
    global dt_r
    dt_l = 1.7
    fre_l=1/((20+dt_l)*0.001)
    dc_l=dt_l/(20+dt_l)*100
    p_l.ChangeFrequency(fre_l)
    p_l.ChangeDutyCycle(dc_l)
    my_left_value[(50,200)]=my_left_value[(50,150)]
    my_left_value[(50,150)]=my_left_value[(50,100)]
    my_left_value[(50,100)]='Counter-Clk'
    end = time.time()
    cost = end - start
    my_left_time[(100,200)]=my_left_time[(100,150)]
    my_left_time[(100,150)]=my_left_time[(100,100)]
    my_left_time[(100,100)]=str(int(cost))


# right servo clockwise
def GPIO17_callback(channel):
    print('Right servo clockwise')
    global dt_l
    global dt_r
    dt_r = 1.3
    fre_r=1/((20+dt_r)*0.001)
    dc_r=dt_r/(20+dt_r)*100
    p_r.ChangeFrequency(fre_r)
    p_r.ChangeDutyCycle(dc_r)
    my_right_value[(255,200)]=my_right_value[(255,150)]
    my_right_value[(255,150)]=my_right_value[(255,100)]
    my_right_value[(255,100)]='Clkwise'
    end = time.time()
    cost = end - start
    my_right_time[(305,200)]=my_right_time[(305,150)]
    my_right_time[(305,150)]=my_right_time[(305,100)]
    my_right_time[(305,100)]=str(int(cost)) 

# right servo stop
def GPIO5_callback(channel):
    print('Right servo stop')
    global dt_l
    global dt_r
    dt_r = 0
    fre_r=1/((20+dt_r)*0.001)
    dc_r=dt_r/(20+dt_r)*100
    p_r.ChangeFrequency(fre_r)
    p_r.ChangeDutyCycle(dc_r)
    my_right_value[(255,200)]=my_right_value[(255,150)]
    my_right_value[(255,150)]=my_right_value[(255,100)]
    my_right_value[(255,100)]='Stop'
    end = time.time()
    cost = end - start
    my_right_time[(305,200)]=my_right_time[(305,150)]
    my_right_time[(305,150)]=my_right_time[(305,100)]
    my_right_time[(305,100)]=str(int(cost))
    

    

# right servo counter-clockwise
def GPIO13_callback(channel):
    print('Right servo counter-clockwise')
    global dt_l
    global dt_r
    dt_r = 1.7
    fre_r=1/((20+dt_r)*0.001)
    dc_r=dt_r/(20+dt_r)*100
    p_r.ChangeFrequency(fre_r)
    p_r.ChangeDutyCycle(dc_r)
    my_right_value[(255,200)]=my_right_value[(255,150)]
    my_right_value[(255,150)]=my_right_value[(255,100)]
    my_right_value[(255,100)]='Counter-Clk'  
    end = time.time()
    cost = end - start
    my_right_time[(305,200)]=my_right_time[(305,150)]
    my_right_time[(305,150)]=my_right_time[(305,100)]
    my_right_time[(305,100)]=str(int(cost))


GPIO.add_event_detect(22, GPIO.FALLING, callback=GPIO22_callback, bouncetime=300)
GPIO.add_event_detect(23, GPIO.FALLING, callback=GPIO23_callback, bouncetime=300)
GPIO.add_event_detect(17, GPIO.FALLING, callback=GPIO17_callback, bouncetime=300)
GPIO.add_event_detect(27, GPIO.FALLING, callback=GPIO27_callback, bouncetime=300)
GPIO.add_event_detect(5, GPIO.FALLING, callback=GPIO5_callback, bouncetime=300)
GPIO.add_event_detect(13, GPIO.FALLING, callback=GPIO13_callback, bouncetime=300)






#timelimit=30
#start_time=time.time()
Code_Running=True

start=time.time()
while Code_Running:
    
    screen.fill(BLACK)# Erase the Work space
    pygame.draw.circle(screen,COLOR,[160,120],40,40)

    for text_pos,my_text in my_buttons.items():
        text_surface=my_font_buttons.render(my_text, True, WHITE)
        rect=text_surface.get_rect(center=text_pos)
        screen.blit(text_surface,rect)

    for my_text,text_pos in my_his.items():
        text_surface=my_font_his.render(my_text, True, WHITE)
        rect=text_surface.get_rect(center=text_pos)
        screen.blit(text_surface,rect)
  
    for text_pos,my_text in my_left_value.items():
        text_surface=my_font_his.render(my_text, True, WHITE)
        rect=text_surface.get_rect(center=text_pos)
        screen.blit(text_surface,rect)
  
  
    for text_pos,my_text in my_left_time.items():
        text_surface=my_font_his.render(my_text, True, WHITE)
        rect=text_surface.get_rect(center=text_pos)
        screen.blit(text_surface,rect)

  
    for text_pos,my_text in my_right_value.items():
        text_surface=my_font_his.render(my_text, True, WHITE)
        rect=text_surface.get_rect(center=text_pos)
        screen.blit(text_surface,rect)
  
  
    for text_pos,my_text in my_right_time.items():
        text_surface=my_font_his.render(my_text, True, WHITE)
        rect=text_surface.get_rect(center=text_pos)
        screen.blit(text_surface,rect)

    
    pygame.display.flip()
    
    
    
    for event in pygame.event.get():
        if(event.type is MOUSEBUTTONDOWN):
            pos=pygame.mouse.get_pos()
        elif(event.type is MOUSEBUTTONUP):
            pos=pygame.mouse.get_pos()
            x,y=pos
            #print("Hit at",x,y);
            s1="Hit at " + str(x)+", "+str(y)
            print(s1)
             
            #quit is pressed
            if y>200:
                if x>200 and x<280:
                  print"quit is pressed"
                  Code_Running=False
            if (x-160)**2+(y-120)**2 < 1600:
                if COLOR==RED:
                    COLOR = GREEN
                    my_buttons[(160,120)]='RESUME'
                    temp_dt_r=dt_r;
                    print('temp dt_r: '+str(temp_dt_r))
                    temp_dt_l=dt_l;
                    print('temp dt_l: '+str(temp_dt_l))
                    dt_r = 0
                    fre_r=1/((20+dt_r)*0.001)
                    dc_r=dt_r/(20+dt_r)*100
                    p_r.ChangeFrequency(fre_r)
                    p_r.ChangeDutyCycle(dc_r)
                    dt_l = 0
                    fre_l=1/((20+dt_l)*0.001)
                    dc_l=dt_l/(20+dt_l)*100
                    p_l.ChangeFrequency(fre_l)
                    p_l.ChangeDutyCycle(dc_l)
                elif COLOR==GREEN:
                    COLOR = RED
                    my_buttons[(160,120)]='STOP'
                    dt_r = temp_dt_r
                    #print('dt_r: '+str(dt_r))
                    fre_r=1/((20+dt_r)*0.001)
                    dc_r=dt_r/(20+dt_r)*100
                    p_r.ChangeFrequency(fre_r)
                    p_r.ChangeDutyCycle(dc_r)
                    dt_l = temp_dt_l
                    #print('dt_l: '+str(dt_l))
                    fre_l=1/((20+dt_l)*0.001)
                    dc_l=dt_l/(20+dt_l)*100
                    p_l.ChangeFrequency(fre_l)
                    p_l.ChangeDutyCycle(dc_l)
                    
                    
p_r.stop()
p_l.stop()
GPIO.cleanup()
                    
                
            
                  
                  
    
                    
                   


                    
                    
                    
                    
                     
                    

              

