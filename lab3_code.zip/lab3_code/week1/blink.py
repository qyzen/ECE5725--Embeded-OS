import RPi.GPIO as GPIO
import subprocess
import time

GPIO.setmode(GPIO.BCM)
GPIO.setup(26, GPIO.OUT)

fre=1
dc=50
p = GPIO.PWM(26,fre)
p.start(dc)
s = raw_input("press return to continue...")
p.stop()
GPIO.cleanup()


