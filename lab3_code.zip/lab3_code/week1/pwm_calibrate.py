import RPi.GPIO as GPIO
import subprocess
import time

GPIO.setmode(GPIO.BCM)
GPIO.setup(6, GPIO.OUT)
dt=1.5
fre=1/((20+dt)*0.001)
dc=dt/(20+dt)*100
p = GPIO.PWM(6,fre)
p.start(dc)
try:
  while 1:
      time.sleep(0.1)
except KeyboardInterrupt:
  pass

p.stop()
GPIO.cleanup()
