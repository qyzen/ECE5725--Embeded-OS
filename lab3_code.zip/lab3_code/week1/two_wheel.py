import RPi.GPIO as GPIO
import subprocess
import time



GPIO.setmode(GPIO.BCM)

#GIPO for Servo
GPIO.setup(26, GPIO.OUT) #for left servo
GPIO.setup(6, GPIO.OUT) #for right servo

# GPIo for buttons
GPIO.setup(17, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(22, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(27, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(23, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(5, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(13, GPIO.IN, pull_up_down=GPIO.PUD_UP)




# Initial setup for left servo
dt_l=1.5
fre_l=1/((20+dt_l)*0.001)
dc_l=dt_l/(20+dt_l)*100
p_l = GPIO.PWM(26,fre_l)
p_l.start(dc_l)

# Initial setup for right servo
dt_r=1.5
fre_r=1/((20+dt_r)*0.001)
dc_r=dt_r/(20+dt_r)*100
p_r = GPIO.PWM(6,fre_r)
p_r.start(dc_r)



# Left servo clockwise
def GPIO27_callback(channel):
    print('Left servo clockwise')
    dt_l = 1.3
    fre_l=1/((20+dt_l)*0.001)
    dc_l=dt_l/(20+dt_l)*100
    p_l.ChangeFrequency(fre_l)
    p_l.ChangeDutyCycle(dc_l)

# Left servo stop
def GPIO23_callback(channel):
    print('Left servo stop')
    dt_l = 0
    fre_l=1/((20+dt_l)*0.001)
    dc_l=dt_l/(20+dt_l)*100
    p_l.ChangeFrequency(fre_l)
    p_l.ChangeDutyCycle(dc_l)


# Left servo counter-clockwise
def GPIO22_callback(channel):
    print('Left servo counter-clockwise')
    dt_l = 1.7
    fre_l=1/((20+dt_l)*0.001)
    dc_l=dt_l/(20+dt_l)*100
    p_l.ChangeFrequency(fre_l)
    p_l.ChangeDutyCycle(dc_l)


# right servo clockwise
def GPIO17_callback(channel):
    print('Right servo clockwise')
    dt_r = 1.3
    fre_r=1/((20+dt_r)*0.001)
    dc_r=dt_r/(20+dt_r)*100
    p_r.ChangeFrequency(fre_r)
    p_r.ChangeDutyCycle(dc_r)
    

# right servo stop
def GPIO5_callback(channel):
    print('Right servo stop')
    dt_r = 0
    fre_r=1/((20+dt_r)*0.001)
    dc_r=dt_r/(20+dt_r)*100
    p_r.ChangeFrequency(fre_r)
    p_r.ChangeDutyCycle(dc_r)
    

# right servo counter-clockwise
def GPIO13_callback(channel):
    print('Right servo counter-clockwise')
    dt_r = 1.7
    fre_r=1/((20+dt_r)*0.001)
    dc_r=dt_r/(20+dt_r)*100
    p_r.ChangeFrequency(fre_r)
    p_r.ChangeDutyCycle(dc_r)
    
GPIO.add_event_detect(22, GPIO.FALLING, callback=GPIO22_callback, bouncetime=300)
GPIO.add_event_detect(23, GPIO.FALLING, callback=GPIO23_callback, bouncetime=300)
GPIO.add_event_detect(17, GPIO.FALLING, callback=GPIO17_callback, bouncetime=300)
GPIO.add_event_detect(27, GPIO.FALLING, callback=GPIO27_callback, bouncetime=300)
GPIO.add_event_detect(5, GPIO.FALLING, callback=GPIO5_callback, bouncetime=300)
GPIO.add_event_detect(13, GPIO.FALLING, callback=GPIO13_callback, bouncetime=300)

try:
  while 1:
      time.sleep(0.1)
except KeyboardInterrupt:
  pass

p_l.stop()
p_r.stop()
GPIO.cleanup()
