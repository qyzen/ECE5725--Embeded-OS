import pygame
from pygame.locals import* # for event mouse variables
import os
import time
import RPi.GPIO as GPIO
import subprocess


os.putenv('SDL_VIDEODRIVER','fbcon') #display on piTFT
os.putenv('SDL_FBDEV','/dev/fb1') 
os.putenv('SDL_MOUSEDRV','TSLIB') #track mouse clicks on piTFT
os.putenv('SDL_MOUSEDEV','/dev/input/touchscreen')

pygame.init()
pygame.mouse.set_visible(False)
WHITE=255,255,255
RED = 255,0,0
GREEN = 0,255,0
BLACK=0,0,0
COLOR=RED
screen=pygame.display.set_mode((320,240))
my_font_buttons=pygame.font.Font(None,25)
my_font_his=pygame.font.Font(None,20)
my_buttons={(240,220):'quit',(160,120):'STOP'}
my_his={'Left History':(50,50),'Right History':(265,50)}
my_left_value={(50,100):'Stop',(50,150):'Stop',(50,200):'Stop'}
my_left_time={(100,100):'0',(100,150):'0',(100,200):'0'}
my_right_value={(255,100):'Stop',(255,150):'Stop',(255,200):'Stop'}
my_right_time={(305,100):'0',(305,150):'0',(305,200):'0'}


screen.fill(BLACK)  #Erase the work space

GPIO.setmode(GPIO.BCM)

#GIPO for Servo
GPIO.setup(26, GPIO.OUT) #for left servo
GPIO.setup(6, GPIO.OUT) #for right servo

# GPIo for buttons
GPIO.setup(17, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(22, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(27, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(23, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(5, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(13, GPIO.IN, pull_up_down=GPIO.PUD_UP)


# Initial setup for left servo
dt_l=0
fre_l=1/((20+dt_l)*0.001)
dc_l=dt_l/(20+dt_l)*100
p_l = GPIO.PWM(26,fre_l)
p_l.start(dc_l)

# Initial setup for right servo
dt_r=0
fre_r=1/((20+dt_r)*0.001)
dc_r=dt_r/(20+dt_r)*100
p_r = GPIO.PWM(6,fre_r)
p_r.start(dc_r)


def forward():
    global dt_l
    global dt_r
    dt_l = 1.4
    dt_r = 1.6
    
    fre_l=1/((20+dt_l)*0.001)
    dc_l=dt_l/(20+dt_l)*100
    p_l.ChangeFrequency(fre_l)
    p_l.ChangeDutyCycle(dc_l)
    
    
    fre_r=1/((20+dt_r)*0.001)
    dc_r=dt_r/(20+dt_r)*100
    p_r.ChangeFrequency(fre_r)
    p_r.ChangeDutyCycle(dc_r)
    
    
    
def backward():
    global dt_l
    global dt_r
    dt_l = 1.6
    dt_r = 1.4
    
    fre_l=1/((20+dt_l)*0.001)
    dc_l=dt_l/(20+dt_l)*100
    p_l.ChangeFrequency(fre_l)
    p_l.ChangeDutyCycle(dc_l)
    
    fre_r=1/((20+dt_r)*0.001)
    dc_r=dt_r/(20+dt_r)*100
    p_r.ChangeFrequency(fre_r)
    p_r.ChangeDutyCycle(dc_r)
    
    
def stop():
    global dt_l
    global dt_r
    dt_l = 0
    dt_r = 0
    
    fre_l=1/((20+dt_l)*0.001)
    dc_l=dt_l/(20+dt_l)*100
    p_l.ChangeFrequency(fre_l)
    p_l.ChangeDutyCycle(dc_l)
    
    fre_r=1/((20+dt_r)*0.001)
    dc_r=dt_r/(20+dt_r)*100
    p_r.ChangeFrequency(fre_r)
    p_r.ChangeDutyCycle(dc_r)
    
    
def Left():
    global dt_l
    global dt_r
    dt_l = 1.3
    dt_r = 1.3
    
    fre_l=1/((20+dt_l)*0.001)
    dc_l=dt_l/(20+dt_l)*100
    p_l.ChangeFrequency(fre_l)
    p_l.ChangeDutyCycle(dc_l)
    
    fre_r=1/((20+dt_r)*0.001)
    dc_r=dt_r/(20+dt_r)*100
    p_r.ChangeFrequency(fre_r)
    p_r.ChangeDutyCycle(dc_r)
    
    
def Right():
    global dt_l
    global dt_r
    dt_l = 1.7
    dt_r = 1.7
    
    fre_l=1/((20+dt_l)*0.001)
    dc_l=dt_l/(20+dt_l)*100
    p_l.ChangeFrequency(fre_l)
    p_l.ChangeDutyCycle(dc_l)
    
    fre_r=1/((20+dt_r)*0.001)
    dc_r=dt_r/(20+dt_r)*100
    p_r.ChangeFrequency(fre_r)
    p_r.ChangeDutyCycle(dc_r)




# Left servo clockwise
def GPIO27_callback(channel):
    print('Left servo clockwise')
    global dt_l
    global dt_r
    dt_l = 1.3
    fre_l=1/((20+dt_l)*0.001)
    dc_l=dt_l/(20+dt_l)*100
    p_l.ChangeFrequency(fre_l)
    p_l.ChangeDutyCycle(dc_l)
    my_left_value[(50,200)]=my_left_value[(50,150)]
    my_left_value[(50,150)]=my_left_value[(50,100)]
    my_left_value[(50,100)]='Clkwise'
    end = time.time()
    cost = end - start
    my_left_time[(100,200)]=my_left_time[(100,150)]
    my_left_time[(100,150)]=my_left_time[(100,100)]
    my_left_time[(100,100)]=str(int(cost))
    
    
    

# Left servo stop
def GPIO23_callback(channel):
    print('Left servo stop')
    global dt_l
    global dt_r
    dt_l = 0
    fre_l=1/((20+dt_l)*0.001)
    dc_l=dt_l/(20+dt_l)*100
    p_l.ChangeFrequency(fre_l)
    p_l.ChangeDutyCycle(dc_l)
    my_left_value[(50,200)]=my_left_value[(50,150)]
    my_left_value[(50,150)]=my_left_value[(50,100)]
    my_left_value[(50,100)]='Stop'
    end = time.time()
    cost = end - start
    my_left_time[(100,200)]=my_left_time[(100,150)]
    my_left_time[(100,150)]=my_left_time[(100,100)]
    my_left_time[(100,100)]=str(int(cost))


# Left servo counter-clockwise
def GPIO22_callback(channel):
    print('Left servo counter-clockwise')
    global dt_l
    global dt_r
    dt_l = 1.7
    fre_l=1/((20+dt_l)*0.001)
    dc_l=dt_l/(20+dt_l)*100
    p_l.ChangeFrequency(fre_l)
    p_l.ChangeDutyCycle(dc_l)
    my_left_value[(50,200)]=my_left_value[(50,150)]
    my_left_value[(50,150)]=my_left_value[(50,100)]
    my_left_value[(50,100)]='Counter-Clk'
    end = time.time()
    cost = end - start
    my_left_time[(100,200)]=my_left_time[(100,150)]
    my_left_time[(100,150)]=my_left_time[(100,100)]
    my_left_time[(100,100)]=str(int(cost))


# right servo clockwise
def GPIO17_callback(channel):
    print('Right servo clockwise')
    global dt_l
    global dt_r
    dt_r = 1.3
    fre_r=1/((20+dt_r)*0.001)
    dc_r=dt_r/(20+dt_r)*100
    p_r.ChangeFrequency(fre_r)
    p_r.ChangeDutyCycle(dc_r)
    my_right_value[(255,200)]=my_right_value[(255,150)]
    my_right_value[(255,150)]=my_right_value[(255,100)]
    my_right_value[(255,100)]='Clkwise'
    end = time.time()
    cost = end - start
    my_right_time[(305,200)]=my_right_time[(305,150)]
    my_right_time[(305,150)]=my_right_time[(305,100)]
    my_right_time[(305,100)]=str(int(cost)) 

# right servo stop
def GPIO5_callback(channel):
    print('Right servo stop')
    global dt_l
    global dt_r
    dt_r = 0
    fre_r=1/((20+dt_r)*0.001)
    dc_r=dt_r/(20+dt_r)*100
    p_r.ChangeFrequency(fre_r)
    p_r.ChangeDutyCycle(dc_r)
    my_right_value[(255,200)]=my_right_value[(255,150)]
    my_right_value[(255,150)]=my_right_value[(255,100)]
    my_right_value[(255,100)]='Stop'
    end = time.time()
    cost = end - start
    my_right_time[(305,200)]=my_right_time[(305,150)]
    my_right_time[(305,150)]=my_right_time[(305,100)]
    my_right_time[(305,100)]=str(int(cost))
    

    

# right servo counter-clockwise
def GPIO13_callback(channel):
    print('Right servo counter-clockwise')
    global dt_l
    global dt_r
    dt_r = 1.7
    fre_r=1/((20+dt_r)*0.001)
    dc_r=dt_r/(20+dt_r)*100
    p_r.ChangeFrequency(fre_r)
    p_r.ChangeDutyCycle(dc_r)
    my_right_value[(255,200)]=my_right_value[(255,150)]
    my_right_value[(255,150)]=my_right_value[(255,100)]
    my_right_value[(255,100)]='Counter-Clk'  
    end = time.time()
    cost = end - start
    my_right_time[(305,200)]=my_right_time[(305,150)]
    my_right_time[(305,150)]=my_right_time[(305,100)]
    my_right_time[(305,100)]=str(int(cost))


GPIO.add_event_detect(22, GPIO.FALLING, callback=GPIO22_callback, bouncetime=300)
GPIO.add_event_detect(23, GPIO.FALLING, callback=GPIO23_callback, bouncetime=300)
GPIO.add_event_detect(17, GPIO.FALLING, callback=GPIO17_callback, bouncetime=300)
GPIO.add_event_detect(27, GPIO.FALLING, callback=GPIO27_callback, bouncetime=300)
GPIO.add_event_detect(5, GPIO.FALLING, callback=GPIO5_callback, bouncetime=300)
GPIO.add_event_detect(13, GPIO.FALLING, callback=GPIO13_callback, bouncetime=300)






#timelimit=30
#start_time=time.time()
Code_Running=True
Move_start=False # To detect if start is pressed
Stop = False

#start=time.time()
state=0;
temp_period=0;
while Code_Running:
    if Move_start==True:
        if Stop == False:
            time_move_end=time.time()
            period=(temp_period+time_move_end-time_move_start)%21
            if(period>=0 and period<3):
                temp=state
                state = 1
                if (temp != state):
                    end = time.time()
                    cost = end - start
                    my_left_value[(50,200)]=my_left_value[(50,150)]
                    my_left_value[(50,150)]=my_left_value[(50,100)]
                    my_left_value[(50,100)]='Forward'
                    my_left_time[(100,200)]=my_left_time[(100,150)]
                    my_left_time[(100,150)]=my_left_time[(100,100)]
                    my_left_time[(100,100)]=str(int(cost))
                    my_right_value[(255,200)]=my_right_value[(255,150)]
                    my_right_value[(255,150)]=my_right_value[(255,100)]
                    my_right_value[(255,100)]='Forward'  
                    my_right_time[(305,200)]=my_right_time[(305,150)]
                    my_right_time[(305,150)]=my_right_time[(305,100)]
                    my_right_time[(305,100)]=str(int(cost))
                forward()
            elif(period >=3 and period < 6):
                temp=state
                state = 2
                if (temp != state):
                    end = time.time()
                    cost = end - start
                    my_left_value[(50,200)]=my_left_value[(50,150)]
                    my_left_value[(50,150)]=my_left_value[(50,100)]
                    my_left_value[(50,100)]='Stop'
                    my_left_time[(100,200)]=my_left_time[(100,150)]
                    my_left_time[(100,150)]=my_left_time[(100,100)]
                    my_left_time[(100,100)]=str(int(cost))
                    my_right_value[(255,200)]=my_right_value[(255,150)]
                    my_right_value[(255,150)]=my_right_value[(255,100)]
                    my_right_value[(255,100)]='Stop'  
                    my_right_time[(305,200)]=my_right_time[(305,150)]
                    my_right_time[(305,150)]=my_right_time[(305,100)]
                    my_right_time[(305,100)]=str(int(cost))
                stop()
            elif(period >=6 and period < 9):
                temp=state
                state = 3
                if (temp != state):
                    end = time.time()
                    cost = end - start
                    my_left_value[(50,200)]=my_left_value[(50,150)]
                    my_left_value[(50,150)]=my_left_value[(50,100)]
                    my_left_value[(50,100)]='Back'
                    my_left_time[(100,200)]=my_left_time[(100,150)]
                    my_left_time[(100,150)]=my_left_time[(100,100)]
                    my_left_time[(100,100)]=str(int(cost))
                    my_right_value[(255,200)]=my_right_value[(255,150)]
                    my_right_value[(255,150)]=my_right_value[(255,100)]
                    my_right_value[(255,100)]='Back'  
                    my_right_time[(305,200)]=my_right_time[(305,150)]
                    my_right_time[(305,150)]=my_right_time[(305,100)]
                    my_right_time[(305,100)]=str(int(cost))
                backward()
            elif(period >=9 and period < 12):
                temp=state
                state = 4
                if (temp != state):
                    end = time.time()
                    cost = end - start
                    my_left_value[(50,200)]=my_left_value[(50,150)]
                    my_left_value[(50,150)]=my_left_value[(50,100)]
                    my_left_value[(50,100)]='Left'
                    my_left_time[(100,200)]=my_left_time[(100,150)]
                    my_left_time[(100,150)]=my_left_time[(100,100)]
                    my_left_time[(100,100)]=str(int(cost))
                    my_right_value[(255,200)]=my_right_value[(255,150)]
                    my_right_value[(255,150)]=my_right_value[(255,100)]
                    my_right_value[(255,100)]='Left'  
                    my_right_time[(305,200)]=my_right_time[(305,150)]
                    my_right_time[(305,150)]=my_right_time[(305,100)]
                    my_right_time[(305,100)]=str(int(cost))
                Left()
            elif(period >=12 and period < 15):
                temp=state
                state = 5
                if (temp != state):
                    end = time.time()
                    cost = end - start
                    my_left_value[(50,200)]=my_left_value[(50,150)]
                    my_left_value[(50,150)]=my_left_value[(50,100)]
                    my_left_value[(50,100)]='Stop'
                    my_left_time[(100,200)]=my_left_time[(100,150)]
                    my_left_time[(100,150)]=my_left_time[(100,100)]
                    my_left_time[(100,100)]=str(int(cost))
                    my_right_value[(255,200)]=my_right_value[(255,150)]
                    my_right_value[(255,150)]=my_right_value[(255,100)]
                    my_right_value[(255,100)]='Stop'  
                    my_right_time[(305,200)]=my_right_time[(305,150)]
                    my_right_time[(305,150)]=my_right_time[(305,100)]
                    my_right_time[(305,100)]=str(int(cost))
                stop()
            elif(period >=15 and period < 18):
                temp=state
                state = 6
                if (temp != state):
                    end = time.time()
                    cost = end - start
                    my_left_value[(50,200)]=my_left_value[(50,150)]
                    my_left_value[(50,150)]=my_left_value[(50,100)]
                    my_left_value[(50,100)]='Right'
                    my_left_time[(100,200)]=my_left_time[(100,150)]
                    my_left_time[(100,150)]=my_left_time[(100,100)]
                    my_left_time[(100,100)]=str(int(cost))
                    my_right_value[(255,200)]=my_right_value[(255,150)]
                    my_right_value[(255,150)]=my_right_value[(255,100)]
                    my_right_value[(255,100)]='Right'  
                    my_right_time[(305,200)]=my_right_time[(305,150)]
                    my_right_time[(305,150)]=my_right_time[(305,100)]
                    my_right_time[(305,100)]=str(int(cost))
                Right()
            elif(period >=18 and period < 21):
                temp=state
                state = 7
                if (temp != state):
                    end = time.time()
                    cost = end - start
                    my_left_value[(50,200)]=my_left_value[(50,150)]
                    my_left_value[(50,150)]=my_left_value[(50,100)]
                    my_left_value[(50,100)]='Stop'
                    my_left_time[(100,200)]=my_left_time[(100,150)]
                    my_left_time[(100,150)]=my_left_time[(100,100)]
                    my_left_time[(100,100)]=str(int(cost))
                    my_right_value[(255,200)]=my_right_value[(255,150)]
                    my_right_value[(255,150)]=my_right_value[(255,100)]
                    my_right_value[(255,100)]='Stop'  
                    my_right_time[(305,200)]=my_right_time[(305,150)]
                    my_right_time[(305,150)]=my_right_time[(305,100)]
                    my_right_time[(305,100)]=str(int(cost))
                stop()
    
        
    
    
    screen.fill(BLACK)# Erase the Work space
    pygame.draw.circle(screen,COLOR,[160,120],40,40)

    for text_pos,my_text in my_buttons.items():
        text_surface=my_font_buttons.render(my_text, True, WHITE)
        rect=text_surface.get_rect(center=text_pos)
        screen.blit(text_surface,rect)

    for my_text,text_pos in my_his.items():
        text_surface=my_font_his.render(my_text, True, WHITE)
        rect=text_surface.get_rect(center=text_pos)
        screen.blit(text_surface,rect)
  
    for text_pos,my_text in my_left_value.items():
        text_surface=my_font_his.render(my_text, True, WHITE)
        rect=text_surface.get_rect(center=text_pos)
        screen.blit(text_surface,rect)
  
  
    for text_pos,my_text in my_left_time.items():
        text_surface=my_font_his.render(my_text, True, WHITE)
        rect=text_surface.get_rect(center=text_pos)
        screen.blit(text_surface,rect)

  
    for text_pos,my_text in my_right_value.items():
        text_surface=my_font_his.render(my_text, True, WHITE)
        rect=text_surface.get_rect(center=text_pos)
        screen.blit(text_surface,rect)
  
  
    for text_pos,my_text in my_right_time.items():
        text_surface=my_font_his.render(my_text, True, WHITE)
        rect=text_surface.get_rect(center=text_pos)
        screen.blit(text_surface,rect)
        
    if Move_start==False:
        text_surface=my_font_buttons.render('Start', True, WHITE)
        rect=text_surface.get_rect(center=(160,50))
        screen.blit(text_surface,rect)

    
    pygame.display.flip()
    
    
    
    for event in pygame.event.get():
        if(event.type is MOUSEBUTTONDOWN):
            pos=pygame.mouse.get_pos()
        elif(event.type is MOUSEBUTTONUP):
            pos=pygame.mouse.get_pos()
            x,y=pos
            #print("Hit at",x,y);
            s1="Hit at " + str(x)+", "+str(y)
            print(s1)
             
            #quit is pressed
            if y>200:
                if x>200 and x<280:
                  print"quit is pressed"
                  Code_Running=False
            if (x-160)**2+(y-120)**2 < 1600:
                if COLOR==RED:
                    COLOR = GREEN
                    my_buttons[(160,120)]='RESUME'
                    temp_dt_r=dt_r;
                    print('temp dt_r: '+str(temp_dt_r))
                    temp_dt_l=dt_l;
                    print('temp dt_l: '+str(temp_dt_l))
                    dt_r = 0
                    fre_r=1/((20+dt_r)*0.001)
                    dc_r=dt_r/(20+dt_r)*100
                    p_r.ChangeFrequency(fre_r)
                    p_r.ChangeDutyCycle(dc_r)
                    dt_l = 0
                    fre_l=1/((20+dt_l)*0.001)
                    dc_l=dt_l/(20+dt_l)*100
                    p_l.ChangeFrequency(fre_l)
                    p_l.ChangeDutyCycle(dc_l)
                    Stop=True
                    temp_period=period%21
                elif COLOR==GREEN:
                    COLOR = RED
                    my_buttons[(160,120)]='STOP'
                    dt_r = temp_dt_r
                    #print('dt_r: '+str(dt_r))
                    fre_r=1/((20+dt_r)*0.001)
                    dc_r=dt_r/(20+dt_r)*100
                    p_r.ChangeFrequency(fre_r)
                    p_r.ChangeDutyCycle(dc_r)
                    dt_l = temp_dt_l
                    #print('dt_l: '+str(dt_l))
                    fre_l=1/((20+dt_l)*0.001)
                    dc_l=dt_l/(20+dt_l)*100
                    p_l.ChangeFrequency(fre_l)
                    p_l.ChangeDutyCycle(dc_l)
                    Stop=False
                    time_move_start=time.time()
          
            if(Move_start == False):
                if (x>120 and x<200):
                    if y>20 and y <80:
                        Move_start = True
                        start=time.time()
                        time_move_start=time.time()
                
                    
                    
p_r.stop()
p_l.stop()
GPIO.cleanup()
                    
                
            
                  
                  
    
                    
                   


                    
                    
                    
                    
                     
                    

              


